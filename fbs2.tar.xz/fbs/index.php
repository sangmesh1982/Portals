<!Doctype html>
<html>
    <head>
        <title>
            Facility Booking System
        </title>
        <meta http-equiv="Content-Type" content="text/html;charset=UTF-8"> 
        <link rel="stylesheet" href="css/style.css" />
        <link rel="stylesheet" href="css/header.css" />
        <link rel="stylesheet" href="css/facil.css" />
        <script src="js/jquery-3.7.1.js"></script>
        <script src="js/load.js"></script>
              
    </head> 
<body>
    <div class='header'>
        <div class='logo'></div>
        <div class='login'></div>
    </div>
    <div class='body'>
        <div class='left-div-o'></div>
        <div class='left-div'>
            <h2>Facilities</h2>
            <hr>
            <div class='avb-faci'></div>
        </div>
        <div class='right-div-o'></div>
        <div class='right-div'>
            <h2>Facility Booking</h2>
            <hr>
            <div class="fbs-err"></div>
            <div class='book-tbl'></div>
        </div>
    </div>
    <div class='footer'></div>
    <?php require('php/modal.php'); ?>
</body>
</html>