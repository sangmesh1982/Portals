<?php
require('conn.php');
function select_query($tbl,$args,$cond){
    require('conn.php');
    if($tbl!='' && sizeof($args)==0 && sizeof($cond)==0){
        $q='select * from '.$tbl.' order by id asc';
        $qq=$con->query($q);
        return $qq;
    }
    else if($tbl!='' & sizeof($args)==1 & sizeof($cond)==1){
        $q='select * from '.$tbl.' where '.$cond[0].'="'.$args[0].'" order by id asc';
        $qq=$con->query($q);
        return $qq;
    }
    else if($tbl!='' && sizeof($args)==2 && sizeof($cond)==2){
        $q='select * from '.$tbl.' where '.$cond[0].'="'.$args[0].'" and '.$cond[1].'="'.$args[1].'" order by id asc';
        $qq=$con->query($q);
        return $qq;
    }
    else{
        $q='Query Require 3 Parameters';
        echo $q;
    }
}

function insert_query($tbl,$args,$cond){
    require('conn.php');
    $fields='';
    $vals='';
    foreach($cond as $field){ 
        if($fields==''){
            $fields=$field;
            continue;
        }    
        $fields=$field.','.$fields; 
    }
    foreach($args as $arg){
        if($vals==''){
            $vals="'".$arg."'";
            continue;
        }
        $vals="'".$arg."',".$vals; 
    }
    $q='insert into '.$tbl.' ('.$fields.') values ('. $vals.')';
    $con->query($q);
    return true;
}

function update_query($tbl,$args,$cond){
    require('conn.php');
    foreach($cond as $key=>$field){
        if($key!=0){    
            $q='update '.$tbl.' set '.$field.'="'.$args[$key].'" where '.$cond[0].'="'.$args[0].'"';
            $con->query($q);
        }
    }
    return true;
}

function del_query($tbl,$args,$cond){
    require('conn.php');
    $q='delete from '.$tbl.' where '.$cond[0].'="'.$args[0].'" and '.$cond[1].'="'.$args[1].'"';
    $con->query($q);
    return true;
}

?>