<?php
	 $conn = new mysqli('localhost','fbs','r@@t','fbs');
?>