<?php
mysqli_report(MYSQLI_REPORT_OFF);
require('db_str.php');
$con = $conn;
$suf = 'fbs_';
$base = 'localhost/';
$msg = 'hello';
// Check connection
if ($con -> connect_errno) {
  echo "Failed to connect to MySQL: " . $con -> connect_error;
  exit();
}

?> 