<!Doctype html>
<html>
    <head>
        <title>
            Facility Booking - Admin
        </title>
        <meta http-equiv="Content-Type" content="text/html;charset=UTF-8"> 
        <link rel="stylesheet" href="css/style.css" />
        <link rel="stylesheet" href="css/login.css" />
        <link rel="stylesheet" href="css/facil.css" />
        <link rel="stylesheet" href="css/user.css" />
        <link rel="stylesheet" href="css/header.css" />
        <script src="js/jquery-3.7.1.js"></script>
        <script src="js/init.js"></script>
    </head> 
<body>
    <div class='header'>
        <div class='logo'></div>
    </div>
    <div class='body'></div>
    <div class='footer'></div>
    <?php require('common/modal.php'); ?>
</body>
</html>