<script src="admin/js/setup.js"></script>
<div class='fbs-setup'>
    <h2>FBS Setup</h2>
    <hr/>
    <div class='fbs-dts'>
        <div class='fbs-ele-l'>Mysql/Mariadb Root Password:</div>
        <hr style='position:relative;display:block;right:-50%;'/>
        <div class='fbs-ele-l'>Set FBS DB Password:</div>
        <div class='fbs-ele-l'>Confirm Password:</div>
        <hr style='position:relative;display:block;right:-50%;'/>
        <div class='fbs-ele-l'>Site Admin Password:</div>
        <div class='fbs-ele-l'>Confirm Password:</div>
        <div class='fbs-ele-i'><input type='password' class='db_pass' /></div>
        <hr style='position:relative;display:block;visibility:hidden;left:-50%;'/>
        <div class='fbs-ele-i'><input type='password' class='fbs_db_pass1' /></div>
        <div class='fbs-ele-i'><input type='password' class='fbs_db_pass2' /></div>
        <hr style='position:relative;display:block;visibility:hidden;left:-50%;'/>
        <div class='set-eye' style='position:absolute;display:block;top:10%;right:30%;'><?php require ('../common/pass-eye.php'); ?></div>
        <div class='fbs-ele-i'><input type='password' class='site_adm_pass1' /></div>
        <div class='fbs-ele-i'><input type='password' class='site_adm_pass2' /></div>
    </div>    
    <center><div class='fbs-btn fbs-create'>Create</div></center>
</div>
