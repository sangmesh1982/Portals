<script src="js/main.js"></script>
<?php
$logo_url=$_POST['logo_url'];
if($logo_url==''){
    echo "
        <div class='logourl'>
            <center>Logo Url</center>
            <center><input type='text' id='log-url' class='logo-url' size='50%'/></center>
            <br/>
            <center><div class='fbs-btn logo-btn'>Add Logo</div></center>
        </div>
    ";
}
else{
    $head_css=fopen('../css/header.css','w') or die('Unable to write ! Check Permissions !');
    $css=".logo{background-image:url('".$logo_url."');}";
    fwrite($head_css,$css);
    copy('../css/header.css','../../css/header.css');
    echo "<div class='logo_done'>Logo has been Setup ! will effect on next Reload !</div>";
    fclose($head_css);
}
?>
