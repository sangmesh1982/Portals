<?php
mysqli_report(MYSQLI_REPORT_OFF);
date_default_timezone_set('Asia/Kolkata');
$db_pass=$_POST['db_pass'];
$fbs_pass=$_POST['fbs_pass'];
$site_adm_ne=$_POST['site_adm'];
$site_adm=encrypt_string($site_adm_ne);
$suf='fbs.fbs_';
$conn = new mysqli('localhost','root',$db_pass);
if($conn->connect_errno){
    die('Connection Error'. $conn->connect_error);
}
else{
    $q='create database fbs';
    if($conn->query($q)===true){
        $qu_db="create user 'fbs'@'localhost' identified by '".$fbs_pass."'";
        $qu_gnt="grant all privileges on fbs.* to 'fbs'@'localhost'";

        if($conn->query($qu_db)===true && $conn->query($qu_gnt)===true){
            echo 'Database Created !';
        }
        
        $qu="create table ".$suf."users(
            id INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(50) NOT NULL,
            username VARCHAR(25) NOT NULL,
            password VARCHAR(128) NOT NULL,
            email VARCHAR(64),
            level VARCHAR(2) NOT NULL,
            created TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )";
        $qf="create table ".$suf."facilities(
            id INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            facility VARCHAR(25) NOT NULL,
            capacity VARCHAR(10) NOT NULL,
            description VARCHAR(75),
            created TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        
        )";
        $qfa="create table ".$suf."faci_assign(
            id INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            userid VARCHAR(5) NOT NULL,
            facid VARCHAR(5) NOT NULL,
            date_assign TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        
        )";
        $qbk="create table ".$suf."bookings(
            id INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            faci_id VARCHAR(10) NOT NULL,
            request_by VARCHAR(25) NOT NULL,
            email VARCHAR(35),
            event VARCHAR(64) NOT NULL,
            description VARCHAR(100),
            start_time TIMESTAMP NOT NULL,
            end_time TIMESTAMP NOT NULL,
            approval varchar(2) NOT NULL DEFAULT 0, 
            request_on TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            removed INT(2) DEFAULT 0,
            remark VARCHAR(50)
        )";
        $qrl="create table ".$suf."levels(
            id INT(3) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            type VARCHAR(25) NOT NULL,
            level INT(2) NOT NULL,
            created_on TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )";

        if($conn->query($qu)===true){
            echo "<br/>Users Table Created !";
            $qsa="insert into ".$suf."users (name,username,password,level) values ('Site Admin','admin','".$site_adm."','1')";
            if($conn->query($qsa)===true){
                echo "<br/>Site Admin Created !";
            }
            else{
                echo "Error".$conn->error;
            }
        }
        if($conn->query($qf)===true && $conn->query($qfa)===true && $conn->query($qbk)===true && $conn->query($qrl)===true){
            echo "<br/>All Required Tables Created !";
            $qrol="insert into ".$suf."levels (type,level) Values ('Super Admin','1')";
            if($conn->query($qrol)===true){
                echo "<br/>Super Admin Role Assinged !<br/>";            
            }
            $db_file = fopen("../config/db_str.php", "w") or die("Unable to write Configuration, Please check Permissions !");
            $c_str="<?php\n";
            fwrite($db_file, $c_str);
            $c_str = "\t \$conn = new mysqli('localhost','fbs','".$fbs_pass."','fbs');";
            fwrite($db_file, $c_str);
            $c_str="\n?>";
            fwrite($db_file, $c_str);
            fclose($db_file);
            copy('../config/db_str.php','../admin/config/db_str.php');
            chmod('../config/conn.php','0600');
            chmod('../config/db_str.php','0600');
            chmod('../config/config.php','0600');
            chmod('../admin/config/db_str.php','0600');
            echo "<div class='setup done'>Done!</div>";
        }
        else{
            echo "Error".$conn->error;
        }
    }
    else{
        die('FBS DB Already Exists !'. $conn->connect_error);
    }
}

function encrypt_string( $string, $key = '', $iv = '', $method = '' ) {
    $encrypt_method = empty( $method ) ? 'AES-256-CBC' : $method;
    $secret_key = empty( $key ) ? 'random' : $key;
    $secret_iv  = empty( $iv  ) ? 'random' : $iv;
    $key = hash( 'sha256', $secret_key );
    $iv = substr( hash( 'sha256', $secret_iv ), 0, 16 );
    return base64_encode( openssl_encrypt( $string, $encrypt_method, $key, 0, $iv ) );
}

?>