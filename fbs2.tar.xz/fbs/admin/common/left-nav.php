<script src="js/main.js"></script>
<script src="js/facility/fa_reload.js"></script>
<script src="js/users/ut_reload.js"></script>
<?php 
require('../config/config.php');
$uid=$_POST['uid'];
$q=select_query($suf.'users',$a=array($uid),$b=array('id'));
$qrow=$q->fetch_row();

if($qrow[5]!=''){
    $ql=select_query($suf.'levels',$aa=array($qrow[5]),$bb=array('id'));
    $qlr=$ql->fetch_row();
    if($qlr[2]=='1')
    {
        echo "
            <!--div class='l-btn green' data-text='dashboard'>Dashboard</div-->
            <div class='std-div'><h2> FBS Management </h2></div>
            <div class='l-btn green' data-text='booking-mgmt'>Bookings Management</div>
            <div class='faci-list'></div>
            <div class='l-btn' data-text='faci-mgmt'>Facility Management</div>
            <div class='l-btn' data-text='user-mgmt'>User Management</div>
            <div class='l-btn' data-text='logout'>Log Out</div>
        ";
    }
    else if($qlr[2]=='2')
    {
        echo "
            <!--div class='l-btn green' data-text='dashboard'>Dashboard</div-->
            <div class='l-btn' data-text='booking-mgmt'>Bookings Management</div>
            <div class='faci-list'></div>
            <div class='l-btn' data-text='faci-mgmt'>Facility Management</div>
            <div class='l-btn' data-text='logout'>Log Out</div>
        ";
    }
    else if($qlr[2]=='3')
    {
        echo "
            <!--div class='l-btn green' data-text='dashboard'>Dashboard</div-->
            <div class='l-btn' data-text='booking-mgmt'>Bookings Management</div>
            <div class='faci-list'></div>
            <div class='l-btn' data-text='logout'>Log Out</div>
        ";
    }

}
?>

