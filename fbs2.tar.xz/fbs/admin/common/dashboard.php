<div class='b-r-dash'>
    <h1>Dashboard</h1>
    <hr/>
    <div class='dash'>
        <div class='dash1'></div><div class='dash2'></div>
        <div class='dash3'></div><div class='dash3'></div>
    </div>
</div>