<?php
$uname=$_POST['uname'];
$upass=encrypt_pass($_POST['upass']);

require_once '../config/conn.php';
$q='select * from '.$suf.'users where username="'.$uname.'" and password="'.$upass.'"';
$qr=$con->query($q);
$qrow=$qr->fetch_row();
if($qrow==0){
    echo json_encode([
        'msg'=>'Invalid Login Details !'
    ]);
}
else{
    if($qrow[2]!=$uname || $qrow[3]!=$upass){
        echo json_encode([
            'msg'=>'Invalid Username or Password !'
        ]);
    }
    else{
        echo json_encode([
            'msg'=>'success',
            'userid'=>$qrow[0],
            'username'=>$qrow[1]
        ]);
    }
}

function encrypt_pass( $string, $key = '', $iv = '', $method = '' ) {
    $encrypt_method = empty( $method ) ? 'AES-256-CBC' : $method;
    $secret_key = empty( $key ) ? 'random' : $key;
    $secret_iv  = empty( $iv  ) ? 'random' : $iv;
    $key = hash( 'sha256', $secret_key );
    $iv = substr( hash( 'sha256', $secret_iv ), 0, 16 );
    return base64_encode( openssl_encrypt( $string, $encrypt_method, $key, 0, $iv ) );
}

?>
