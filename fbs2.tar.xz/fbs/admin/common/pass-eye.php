<div class='pass-eye'></div>
<style>
.pass-eye{
    position:absolute;
    display:block;
    width:26px;
    height:24px;
    top:5%;
    left:2%;
    background:linear-gradient(#fab5b5,#fff,#eee,#facece,#fab5b5);
    border:0.5px solid #222;
    border-top: 9px solid #444;
    border-bottom: 0.5px dotted #222;
    border-right: 7px solid #444;
    border-top-left-radius: 25px;
    border-bottom-left-radius: 2px;
    border-bottom-right-radius: 22px;
    transform:rotateZ(35deg);
    box-shadow: 0 0 8px #000, 0 0 10px rgb(255, 50, 0), 0 0 30px rgb(255, 150, 120);
    z-index:99;
    cursor:pointer;
    user-select: none;
    animation: blink 5s infinite;
}
.pass-eye::before{
    content:'(';
    font-size: 80px;
    color:#444;
    position:absolute;
    top: -245%;
    left: -30%;
    transform: rotate3d(1,0,1,58deg);
    text-shadow: 0 0 calc(0.5vh) #000, 0 0 calc(2vh) rgb(255, 50, 0), 0 0 calc(3vh) rgb(255, 150, 120);
    z-index:99;
}
.pass-eye::after{
    content:'\25C9';
    font-size:24px;
    color:#333;
    text-shadow: 0 0 3px #025032;
    position:absolute;
    top:-20%;
    left:15%;
    z-index:9;
    animation: wink 4s infinite;
    
}
.pass-eye:hover{
    animation: turn-it 2s infinite;
    transform:rotate3d(1,1,1,70deg);
    
}

@keyframes turn-it{
    0%{transform:rotate3d(1,1,1,70deg);}
    50%{transform:rotate3d(1,1,1,65deg);}
    75%{transform:rotate3d(1,1,1,65deg);}
    100%{transform:rotate3d(1,1,1,70deg);}
}

@keyframes wink{
    0%{top:-20%;left:15%;}
    50%{top:-20%;left:15%;}
    70%{top:-20%;left:15%;}
    80%{top:-15%;left:10%;}
    90%{top:-15%;left:10%;}
    95%{top:-20%;left:15%;}
    100%{top:-20%;left:15%;}
}
@keyframes blink{
    0%{border-top-left-radius: 25px; border-bottom-left-radius: 3px; border-bottom-right-radius: 22px; background:linear-gradient(#fab5b5,#fff,#eee,#facece,#fab5b5);}
    95%{border-top-left-radius: 25px; border-bottom-left-radius: 3px; border-bottom-right-radius: 22px; background:linear-gradient(#fab5b5,#fff,#eee,#facece,#fab5b5);}
    100%{border-top-left-radius: 175px; border-bottom-left-radius: 1px; border-bottom-right-radius: 175px; background:linear-gradient(#444,#444,#444);}
}


</style>