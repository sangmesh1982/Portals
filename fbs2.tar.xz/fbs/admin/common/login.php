<script src="js/login.js"></script>
<div class='fbs-err'></div>
<form id='login-frm' name='login-frm'>
    <div class='log-l'>
        <div class='frm-ele'>Username</div>
        <div class='frm-ele'>Password</div>
    </div>
    <div class='log-i'>
        <div class='frm-ele'><input type='text' autocomplete='current-password' id='login-uname' name='login-uname' class='uname log-in'/></div>
        <div class='frm-ele'><input type='password' autocomplete='current-password' id='login-pass' name='login-pass' class='upass log-in'/><div class='l-eye'><?php require('pass-eye.php');?></div></div>    
    </div>
</form>
<div class='fbs-btn login-btn'>Login</div> 
<div class='fergot-pass'>Fergot Password</div> 

