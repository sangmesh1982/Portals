<script src="js/load.js"></script>
<div class='left-div-o'></div>
<div class='left-div'></div>
<div class='right-div-o'></div>
<div class='right-div'></div>