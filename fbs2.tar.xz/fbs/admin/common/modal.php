<div class='overlay'></div>
<div class='modal'>
    <div class='modal-close'></div>
    <div class='modal-head'></div>
    <div class='modal-body'></div>
</div>
