<?php

$confirm=$_POST['add'];

if($confirm=='no'){
    $pass1=$_POST['data'];
    $encrypt = encrypt_string( $pass1 );
    echo $encrypt;
}

function encrypt_string( $string, $key = '', $iv = '', $method = '' ) {
    $encrypt_method = empty( $method ) ? 'AES-256-CBC' : $method;
    $secret_key = empty( $key ) ? 'random' : $key;
    $secret_iv  = empty( $iv  ) ? 'random' : $iv;
    $key = hash( 'sha256', $secret_key );
    $iv = substr( hash( 'sha256', $secret_iv ), 0, 16 );
    return base64_encode( openssl_encrypt( $string, $encrypt_method, $key, 0, $iv ) );
}

if($confirm=='yes'){
    require('../../config/conn.php');
    $user=$_POST['name'];
    $uname=$_POST['uname'];
    $pass=$_POST['pass'];
    $email=$_POST['email'];
    $role=$_POST['level'];

    $q="select * from ".$suf."users where username='".$uname."'";
    $qr=$con->query($q);
    if($qr->fetch_row()!=0){
        echo "Username Already Exists !";
    }
    else{
        $qi="insert into ".$suf."users (username,password,name,email,level) values ('$uname','$pass','$user','$email','$role')";
        
        $con->query($qi);
        if(!mysqli_error($con)){
            echo "User $uname has been Added !";
        }
        else{
            echo mysqli_error($con);
        }
    }

}
?>