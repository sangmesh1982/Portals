<?php
require('../../config/conn.php');
$confirm=$_POST['confirm'];

if($confirm=='update'){
    $uid=$_POST['uid'];
    $user=$_POST['name'];
    $uname=$_POST['uname'];
    $pass=$_POST['pass'];
    $email=$_POST['email'];
    $role=$_POST['level'];
    $encrypt = encrypt_string( $pass );

    $qi="update ".$suf."users set username='$uname',password='$encrypt',name='$user',email='$email',level='$role' where id=$uid";
        
    $con->query($qi);
    if(!mysqli_error($con)){
        echo "User $uname has been Updated !";
    }
    else{
        echo mysqli_error($con);
    }
}

function encrypt_string( $string, $key = '', $iv = '', $method = '' ) {
    $encrypt_method = empty( $method ) ? 'AES-256-CBC' : $method;
    $secret_key = empty( $key ) ? 'random' : $key;
    $secret_iv  = empty( $iv  ) ? 'random' : $iv;
    $key = hash( 'sha256', $secret_key );
    $iv = substr( hash( 'sha256', $secret_iv ), 0, 16 );
    return base64_encode( openssl_encrypt( $string, $encrypt_method, $key, 0, $iv ) );
}

?>