<script src="js/users/user_role.js"></script>
<?php
require_once('../../config/config.php');
$role=$_POST['role'];
$level=$_POST['level'];
if($role!='' || $level!=''){
    $q=select_query($suf.'levels',$a=array($role),$b=array('type'));
    $qrow=$q->fetch_row();
    if($qrow[0]==''){
        $q=insert_query($suf.'levels',$a=array($role,$level),$b=array('type','level'));
        if($q==true){
            echo $role." Role has been Added !";
        }
    }
    else{
        echo $role." Role Already Present!";
    } 
}
else{
echo "
    <div class='role-div'>
        <div class='role-msg'></div>
        <div class='role-l'>Name</div>
        <div class='role-i'><input type='text' id='role-name' name='role-name' class='role-name' /></div>
        <hr/>
        <div class='role-l'>Level</div>
        <div class='role-i'>
            <input type='radio' id='admin' name='radio-g1' class='role-adm' value='Admin' data-val='2' />
            <label for='admin'>Admin</lable>
            <input type='radio' id='cord' name='radio-g1' class='role-cord' value='Co-Ordinator' data-val='3' />
            <label for='cord'>Co-Ordinator</lable>
        </div>
        <br/>
        <center><div class='fbs-btn role-save-btn'>Create</div></center>
    </div>
";
}
?>