<script src="js/users/user_mgmt.js"></script>
<script src="js/users/ut_reload.js"></script>
<script src="js/users/user_role.js"></script>

<div class='b-r-user'>
    <h1>User Management</h1>
    <hr/> 
    <h3>Active Users</h3>
    <div class='fbs-err'></div>
    <div class='user-add-btn fbs-btn'>Add User</div><div class='role-add-btn fbs-btn'>Add Roles</div>
    <div class='avb-user'></div>
</div>
