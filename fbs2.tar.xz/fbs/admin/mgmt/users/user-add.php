<script src="js/users/user_add.js"></script>
    <div class='add-user'>
    <div class='user-err'></div>
        <div class='user-ad-new'>
            <div class='l-div'>
                <div class='frm-lbl'>Full Name* : </div>
                <div class='frm-lbl'>User Name* : </div>
                <div class='frm-lbl'>Password* : </div>
                <div class='frm-lbl'>Confirm* : </div>
                <div class='frm-lbl'>Email* : </div>
                <div class='frm-lbl'>Role* : </div>
            </div>
            <div class='i-div'>
                <div class='frm-dt'><input type='text' id='user-name' class='user-name' width='100%' /></div>
                <div class='frm-dt'><input type='text' id='user-new' class='user-new' width='100%'/></div>
                <div class='frm-dt'><input type='password' id='user-pass1' class='user-pass1' width='100%'/></div><div class='u-eye'><?php require('../../common/pass-eye.php');?></div>
                <div class='frm-dt'><input type='password' id='user-pass2' class='user-pass2' width='100%'/></div>
                <div class='frm-dt'><input type='email' id='user-email' class='user-email' width='100%'/></div>
                <div class='frm-dt'><select id='user-role' class='user-role' style='width:auto;font-size:14px;'><option selected disabled hidden>Select Role</option>
                    <?php require('../../config/conn.php');
                        $ql='select * from '.$suf.'levels order by level desc';
                        $qrl=$con->query($ql);
                        while($qrow=$qrl->fetch_array()){
                            if($qrow['id']!='1'){
                                echo "<option data-val=".$qrow['id'].">".$qrow['type']."</option>";
                            }    
                        }
                    ?>    
                    </select>
                </div>
            </div>
              
        </div>
    </div>
    <div class='user-save-btn fbs-btn'>Save</div>
     
    