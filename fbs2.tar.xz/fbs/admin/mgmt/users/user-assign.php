<script src="js/users/assign.js"></script>
<?php
$uid=$_POST['uid'];
$fcid=$_POST['fcid'];
$assign=$_POST['assign'];

if($assign=='list'){
    require_once('../../config/config.php');
    $q=select_query($suf.'facilities',$a=array(),$b=array());
    echo "<div class='fava'>";
    while($qrow=$q->fetch_array()){
        $qr=select_query($suf.'faci_assign',$a=array($uid,$qrow['id']),$b=array('userid','facid'));
        $row=$qr->fetch_row();
        if($row[0]==null){
            echo '<div class="avlbtn avl-fa  blue" data-fac-val="'.$qrow['id'].'" data-uid-val="'.$uid.'">'.$qrow['facility'].'<div class="fa-sense"></div></div>';
        }    
        if($row[0]!=null){
            echo '<div class="avlbtn selected-fa  blue" data-fac-val="'.$qrow['id'].'" data-uid-val="'.$uid.'">'.$qrow['facility'].'<div class="fa-sense"></div></div>';
        } 
    }
    echo "</div>";
}
else if($assign=='assign'){
    require_once('../../config/config.php');
    $qi=insert_query($suf.'faci_assign',$a=array($uid,$fcid),$b=array('userid','facid'));
    echo '<div class="tick"></div>';
}
else if($assign=='resume'){
    require_once('../../config/config.php');
    $qd=del_query($suf.'faci_assign',$a=array($uid,$fcid),$b=array('userid','facid'));
    echo '<div class="cross"></div>';
}
else {
    return false;
}


?>