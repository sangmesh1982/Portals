<?php
//require_once('../../config/config.php');
$uid=$_POST['uid'];
$fcid=$_POST['fcid'];
$assign=$_POST['assign'];
if($assign=='resume'){
    $q=del_query($suf.'faci_assign',$a=array($uid,$fcid),$b=array('userid','facid'));
        echo '<div class="cross"></div>';
}
else{
    return false;
}
?>