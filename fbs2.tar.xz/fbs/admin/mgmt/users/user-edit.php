<script src="js/users/user_edit.js"></script>
<script src="js/users/ut_reload.js"></script>
<div class='add-user'>
    <div class='user-err'></div>
        <div class='user-ad-new'>
            <div class='l-div'>
                <div class='frm-lbl'>Full Name* : </div>
                <div class='frm-lbl'>User Name* : </div>
                <div class='frm-lbl'>Password* : </div>
                <div class='frm-lbl'>Email* : </div>
                <div class='frm-lbl'>Role* : </div>
            </div>
            <div class='i-div'>
                <?php require('../../config/conn.php');
                    $uid=$_POST['uid'];
                    $qu='select * from '.$suf.'users where id="'.$uid.'"';
                    $uq=$con->query($qu);
                    $urow=$uq->fetch_row();
                    $pass=data_decrypt( $urow[3] );
                    echo "
                        <div class='frm-dt'><input type='text' id='user-name' class='user-name' width='100%' value='".$urow[1]."'></div>
                        <div class='frm-dt'><input type='text' id='user-new' class='user-new' width='100%' data-val=".$urow[0]." value=".$urow[2]." ></div>
                        <div class='frm-dt'><input type='password' id='user-pass1' class='user-pass1' width='100%' value=".$pass."></div><div class='u-eye'>";
                        require('../../common/pass-eye.php');
                        echo "</div>
                        <div class='frm-dt'><input type='email' id='user-email' class='user-email' width='100%' value=".$urow[4]." ></div>";
                        if($urow[0]!='1'){
                            echo "<div class='frm-dt'><select id='user-role' class='user-role' style='width:auto;font-size:14px;'><option selected disabled hidden>Select Role</option>";
                            $ql='select * from '.$suf.'levels order by level desc';
                            $qrl=$con->query($ql);
                            while($qrow=$qrl->fetch_array()){
                                if($qrow[0]!='1'){
                                    echo "<option data-val=".$qrow['id'].">".$qrow['type']."</option>";
                                }
                            }
                            echo "</select></div>";    
                        }
                        else {
                            echo "<div class='frm-dt'><select id='user-role' class='user-role' style='width:auto;font-size:14px;'><option selected data-val='1'>Super Admin</option></select></div>";
                        }
                        function data_decrypt( $string, $key = '', $iv = '', $method = '' ) {
                            $encrypt_method = empty( $method ) ? 'AES-256-CBC' : $method;
                            $secret_key = empty( $key ) ? 'random' : $key;
                            $secret_iv  = empty( $iv  ) ? 'random' : $iv;
                            $key = hash( 'sha256', $secret_key );
                            $iv = substr( hash( 'sha256', $secret_iv ), 0, 16 );
                            return openssl_decrypt( base64_decode( $string ), $encrypt_method, $key, 0, $iv );    
                        }    

                    ?>   
            </div>
        </div>
</div>
<div class='user-update-btn fbs-btn'>Update</div>

