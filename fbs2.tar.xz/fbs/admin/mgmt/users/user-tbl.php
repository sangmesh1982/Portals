<script src="js/users/user_ops.js"></script>
<script src="js/users/ut_reload.js"></script>
<table>
    <tr class='thead'>
        <th>Sr No</th><th>Name</th><th>Email</th><th>Username</th><th>Role</th>
    </tr>
             <?php 
                require("../../config/config.php");
                $qu=select_query($suf.'users',$a=array(),$b=array());
                $j=1;
                while($rw=$qu->fetch_array()){
                        $ql=select_query($suf.'levels',$a=array($rw['level']),$b=array('id'));
                        $row=$ql->fetch_row();
                        echo "<tr>
                                <td align='center'>".$j."</td>
                                <td>
                                    ".$rw['name']."
                                </td>
                                <td>
                                    ".$rw['email']."
                                </td>
                                <td>
                                    ".$rw['username']."
                                    <span class='user-edit user-update green' data-value='".$rw['id']."' data-text='".$rw['name']."' />Edit</span>
                                    <span class='user-edit user-assign blue' data-value='".$rw['id']."' data-text='".$rw['name']."' />Assign</span>";
                                    if($rw['id']!='1'){
                                        echo "<span class='user-edit user-delete red' data-value='".$rw['id']."' data-text='".$rw['name']."' />Delete</span>";
                                    }
                                echo "    
                                </td>
                                <td>
                                    ".$row[1]."
                                </td>
                            </tr>";
                        $j++;
                    }
                   
            ?> 
</table> 