<script src="js/users/user_delete.js"></script>
<script src="js/users/ut_reload.js"></script>
<?php include "../../config/conn.php";
$uid=$_POST['user_id'];
$uname=$_POST['user_name'];
$confirm=$_POST['confirm'];
$q="delete from ".$suf."users where id='".$uid."'";

if($confirm=='1'){
    
    if($con->query($q)===TRUE){
        echo "User '$uname' has been Deleted !";
    }
    else{
        echo $con->error;
    }
}
if($confirm=='0'){
    echo "
        <div><h3>Are You sure..?</h3></div>
        <div class='fbs-btn usr-delete' data-value='$uid' data-text='$uname'>Yes</div>  
    "; 
}
$con->close();
?>