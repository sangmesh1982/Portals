<script src="js/facility/faci_ops.js"></script>
<script src="js/facility/fa_reload.js"></script>
<table>
    <tr class='thead'>
        <th>Sr No</th><th>Facility</th><th>Capacity</th><th>Description</th>
    </tr>
             <?php 
                require_once('../../config/config.php');
                $q=select_query($suf.'facilities',$a=array(),$b=array());
                $i=1;
                    while($rw=$q->fetch_array()){
                        echo "<tr>
                                <td align='center'>".$i."</td>
                                <td align='left'> 
                                    ".$rw['facility']."
                                    <span class='fa-edit fa-update green' data-value='".$rw['id']."' data-text='".$rw['facility']."' />Edit</span>
                                    <span class='fa-edit fa-delete red' data-value='".$rw['id']."' data-text='".$rw['facility']."' />Delete</span>
                                </td>
                                <td align='center'>
                                    ".$rw['capacity']."
                                </td>
                                <td>
                                    ".$rw['description']."
                                </td>
                            </tr>";
                        $i++;
                    }
                     
            ?> 
</table> 