<?php include "../../config/config.php";
$faci_new=$_POST['faci_new'];
$faci_cap=$_POST['faci_cap'];
$faci_descr=$_POST['faci_descr'];

$qc = "Select * from ".$suf."facilities where facility='$faci_new'";

$qr=$con->query($qc);
$qrc=$qr->fetch_row();

if($qrc[0]!=null)
{
    echo "Facility $faci_new Already Exists !";
}
else{
    $q="insert into ".$suf."facilities (facility,capacity,description) values ('$faci_new', '$faci_cap', '$faci_descr')";
    
    if($con->query($q)===true){
        echo $qid;
        echo "New Facility '$faci_new' has been Added !";
        $fas=select_query($suf.'facilities',$a=array($faci_new),$b=array('facility'));
        $fa_id=$fas->fetch_row();
        $fa_ssi=insert_query($suf.'faci_assign',$a=array('1',$fa_id[0]),$b=array('userid','facid'));
    }
    else{
        echo mysqli_error($con);
    }
}
$con->close();
?>