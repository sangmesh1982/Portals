<script src="js/facility/faci_delete.js"></script>
<script src="js/facility/fa_reload.js"></script>
<?php include "../../config/conn.php";
$fa_id=$_POST['fa_id'];
$fa_name=$_POST['fa_name'];
$confirm=$_POST['confirm'];
$q="delete from ".$suf."facilities where id='".$fa_id."'";

if($confirm=='1'){
    
    if($con->query($q)===TRUE){
        echo "Facility '$fa_name' has been Deleted !";
    }
    else{
        echo $con->error;
    }
}
if($confirm=='0'){
    echo "
        <div><h3>Are You sure..?</h3></div>
        <div class='fbs-btn faci-delete' data-value='$fa_id' data-text='$fa_name'>Yes</div>  
    "; 
}
$con->close();
?>