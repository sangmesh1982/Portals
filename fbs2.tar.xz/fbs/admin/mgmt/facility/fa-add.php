<script src="js/facility/fa_add.js"></script>
    <div class='add-faci'>
        <div class='faci-err'></div>
        <div class='faci-ad-new '>
            <div class='div-t'>
                <div class='span-t'>Facility :</div>     
                <div class='span-t'>Capacity :</div>
                <div class='span-t'>Description :</div>
            </div>
            <div class='div-d'>
                <div class='span-d'><input type='text' id='faci-new' class='faci-new' width='100%'></input></div> 
                <div class='span-d'><input type='number' id='faci-cap' class='faci-cap' width='100%'></input></div>
                <div class='span-d'><textarea type='text' id='faci-descr' class='faci-descr' style="width:90%;" cols='20' rows='2'></textarea></div> 
            </div>
        </div>
    </div> 
    <div class='faci-save fbs-btn'>Save</div>

