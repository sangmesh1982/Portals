<script src="js/facility/faci_mgmt.js"></script>
<script src="js/facility/fa_reload.js"></script>
<div class='b-r-faci'>
    <h1>Facility Management</h1>
    <hr/>
    <h3>Available Facilities</h3>
    <div class='fbs-err'></div>
    <div class='faci-new-btn fbs-btn'>Add</div>
    <div class='avb-faci'></div>
</div>
  