
<?php include "../../config/conn.php";
$faci_id=$_POST['fa_id'];
$faci_name=$_POST['fa_name'];
$faci_cap=$_POST['fa_cap'];
$faci_desc=$_POST['fa_desc'];

$qc = "update ".$suf."facilities set facility='$faci_name', capacity='$faci_cap', description='$faci_desc' where id='$faci_id'";

$con->query($qc);

echo "The Facility '$faci_name' has been Updated!";
$con->close();
?>