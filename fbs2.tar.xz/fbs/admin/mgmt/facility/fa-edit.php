<script src="js/facility/faci_edit.js"></script>
<script src="js/facility/fa_reload.js"></script>
<?php include "../../config/conn.php";
$fa_id=$_POST['fa_id'];

$q="select * from ".$suf."facilities where id='".$fa_id."'";

$qr=$con->query($q);
$qd=$qr->fetch_row();

echo "
<div class='val-div'>
    <div class='val'>
        <input type='text' id='fa_name' class='fa-ele fa_name' data-val='$fa_id' value='".$qd[1]."' />
    </div>
    <div class='val'>
        <input type='number' id='fa_name' class='fa-ele fa_cap' value='".$qd[2]."' />
    </div>
    <div class='val'>
        <textarea type='text' id='fa_name' cols='24' rows='2' class='fa-ele fa_desc' value='".$qd[3]."' />".$qd[3]."</textarea>
    </div>
    
    <div class='val'>
        
    </div>    
</div>  
<div class='fbs-btn faci-edit'>Update</div>
"; 
$con->close();
?>