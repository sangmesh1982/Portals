<script src="js/booking/booking.js"></script>
<script src="js/booking/bkd_reload.js"></script>
<?php
    $uid=$_POST['uid'];
    require_once('../../config/config.php');
    $q=select_query($suf.'facilities',$a=array(),$b=array());
    echo "<div class='fava-admin'>";
    $i=1;
    while($qrow=$q->fetch_array()){
        $qr=select_query($suf.'faci_assign',$a=array($uid,$qrow['id']),$b=array('userid','facid'));
        $row=$qr->fetch_row();
        if($row[0]!=null){
            if($i=='1'){
                echo '<div class="avlbtn-adm avl-fa-adm selected-fa-adm" data-fac-val="'.$qrow['id'].'" >'.$qrow['facility'].'</div>';
                ?><script>tbl_reload(<?php echo $qrow['id']; ?>);</script><?php
            }
            else{
            echo '<div class="avlbtn-adm avl-fa-adm " data-fac-val="'.$qrow['id'].'" >'.$qrow['facility'].'</div>';
            }
        }    
        $i++;
    }
    echo "</div>";
?>