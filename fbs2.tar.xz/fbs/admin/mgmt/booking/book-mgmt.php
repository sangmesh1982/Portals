
<div class='b-r-book'>
    <h1>Booking Management</h1>
    <hr/>
    <div class='book-tbl-adm'></div>
</div>