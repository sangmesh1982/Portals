<script src="js/booking/book_ops.js"></script>

<?php
require_once('../../config/config.php');
$bkid=$_POST['bk_id'];
$ops=$_POST['ops'];
$bk_rem=$_POST['bk_rem'];
if($ops=='none'){
    $qb=select_query($suf.'bookings',$a=array($bkid),$b=array('id'));
    while($row=$qb->fetch_row()){
        echo    '
                <div class="std-div"><b>Request By : </b>'.$row[2].'</div>
                <div class="std-div"><b>From : </b>'.$row[6].'</div>
                <div class="std-div"><b>To :</b>'.$row[7].'</div>
                <div class="std-div"><b>Description :</b>'.$row[5].'</div>
                <hr/>
                <div class="std-div"><b>Remark :</b> <textarea id="bk-remark" class="bk-remark" rows="2" cols="24">'.$row[11].'</textarea></div>
                <div class="fbs-btn book-rej book-bt" data-faci="'.$row[1].'" data-val="'.$bkid.'">Reject</div>
                <div class="fbs-btn book-accpt book-bt" data-faci="'.$row[1].'" data-val="'.$bkid.'">Accept</div>
                <div class="fbs-btn book-del book-bt" data-faci="'.$row[1].'" data-val="'.$bkid.'">Delete</div>
                ';
    }
}   
elseif($ops=='reject'){
    $qr=update_query($suf.'bookings',$a=array($bkid,'-1',$bk_rem),$b=array('id','approval','remark'));
    echo '<h3>Rejected !</h3>';
}
elseif($ops=='accept'){
    $qr=update_query($suf.'bookings',$a=array($bkid,'1',$bk_rem),$b=array('id','approval','remark'));
    echo '<h3>Accepted !</h3>';
}
elseif($ops=='remove'){
    $qr=update_query($suf.'bookings',$a=array($bkid,'1',$bk_rem),$b=array('id','removed','remark'));
    echo '<h3>Deleted !</h3>';
}
else{
    return false;
}

?>
