$('.event-btn').on('click',function(){
    var bk_id=$(this).attr('data-val');
    var bk_evnt=$(this).attr('data-text');
    $('.modal-head').html("Confirm Booking "+bk_evnt+"...");
    $('.modal-body').html('');
    $.ajax({
        url:'mgmt/booking/book_ops.php',
        type:'POST',
        data:{'bk_id':bk_id,'ops':'none'},
        success:function(response){
            $('.modal-body').html(response);
        }
    });
    $('.overlay').show();
    $('.modal').show();
    
})

function tbl_reload(data){
    $('.book-tbl-adm').html('');
    $.ajax({
        url:'mgmt/booking/booked.php',
        type:'POST',
        data:{'fa_id':data},
        success:function(response){
            $('.book-tbl-adm').html(response);
        }
    });
 
}