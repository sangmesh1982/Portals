$(document).ready(function(){
    $('.avlbtn-adm').on('click',function(){
        var fa_id = $(this).attr('data-fac-val');
        var fa_name = $(this).html();
        $('.book-tbl-adm').html('');
        $.ajax({
            url:'mgmt/booking/booked.php',
            type:'POST',
            data:{'fa_id':fa_id,'fa_name':fa_name},
            success:function(response){
                $('.book-tbl-adm').html(response);
            }
        })
        $('.avlbtn-adm').removeClass('selected-fa-adm');
        $(this).addClass('selected-fa-adm');
        
    });
})