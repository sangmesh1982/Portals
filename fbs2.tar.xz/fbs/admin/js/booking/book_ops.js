$('.bk-remark').focus();
$('.book-bt').on('click',function(){
    var bk_id=$(this).attr('data-val');
    var fa_id=$(this).attr('data-faci');
    var bk_rem=$('.bk-remark').val();
    if($(this).hasClass('book-rej')){
        $.ajax({
            url:'mgmt/booking/book_ops.php',
            type:'POST',
            data:{'bk_id':bk_id,'ops':'reject','bk_rem':bk_rem},
            success:function(response){
                $('.modal-body').html(response);
                tbl_reload(fa_id);
            }
        });
    }
    else if($(this).hasClass('book-accpt')){
        $.ajax({
            url:'mgmt/booking/book_ops.php',
            type:'POST',
            data:{'bk_id':bk_id,'ops':'accept','bk_rem':bk_rem},
            success:function(response){
                $('.modal-body').html(response);
                tbl_reload(fa_id);
            }
        });
    }
    else if($(this).hasClass('book-del')){
        $.ajax({
            url:'mgmt/booking/book_ops.php',
            type:'POST',
            data:{'bk_id':bk_id,'ops':'remove','bk_rem':bk_rem},
            success:function(response){
                $('.modal-body').html(response);
                tbl_reload(fa_id);
            }
        });
    }
    else{
        return false;
    }
    setTimeout(function(){m_close();},1000);
});

function m_close(){
    $('.modal').addClass('modalClose');
    $('.overlay').hide();
    $('.modal-head').html('');
    $('.modal-body').html('');
    setTimeout(function(){
        $('.modal').removeClass('modalClose');
        $('.modal').hide();
    },400);
}
