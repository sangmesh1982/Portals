$(document).ready(function(){
        $('.l-btn').on("click",function(){
            var prop=$(this).attr('data-text');
            $('.l-btn').addClass('grey');
            $('.l-btn').removeClass('green');
            $(this).addClass('green');
            var uid = $('.logged').attr('data-val');
            if(prop=='dashboard'){
                $.ajax({
                    url:'common/dashboard.php',
                    success:function(response){
                        $('.right-div').html(response);
                    },
                });
                $('.faci-list').html('');
            }
            else if(prop=='booking-mgmt'){
                $.ajax({
                    url:'mgmt/booking/book-mgmt.php',
                    success:function(response){
                        $('.right-div').html(response);
                    },
                });
                $.ajax({
                    url:'mgmt/booking/user_facis.php',
                    type:'POST',
                    data:{'uid':uid},
                    success:function(response){
                        $('.faci-list').html(response);
                    },
                });
            }
            else if(prop=='faci-mgmt'){
                $.ajax({
                    url:'mgmt/facility/fa-mgmt.php',
                    success:function(response){
                        $('.right-div').html(response);
                    },
                });
                tbl_reload();
                $.ajax({
                    url:'mgmt/facility/fa-mgmt.php',
                    success:function(response){
                        $('.right-div').html(response);
                    },
                });
                $('.faci-list').html('');
            }
            else if(prop=='user-mgmt'){
                $.ajax({
                    url:'mgmt/users/user-mgmt.php',
                    success:function(response){
                        $('.right-div').html(response);
                    },
                });
                utbl_reload();
                $('.faci-list').html('');
            }
            else if(prop=='logout'){
                location.reload();
            }
        });
        $('.logo-btn').on('click',function(){
            var logo_url=$('.logo-url').val();
            if(logo_url!=''){
                $.ajax({
                    url:'setup/logo.php',
                    type:'POST',
                    data:{'logo_url':logo_url},
                    success:function(response){
                        $('.modal-body').html(response);
                    }
                });
            } 
            else{
                $('.modal-body').html('Blank Url ?');
            }
        })    
})