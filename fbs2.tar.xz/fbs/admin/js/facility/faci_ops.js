$('.fa-update').on('click',function(){
    var fa_id=$(this).attr('data-value');
    $('.modal-head').html('Edit '+$(this).attr('data-text')+'...');
    $.ajax({
        url:'mgmt/facility/fa-edit.php',
        type:'POST',
        data:'fa_id='+fa_id,
        success:function(response){
            $('.modal-body').html(response);
        }
    });
    $('.modal').show();
    $('.overlay').show();
});

$('.fa-delete').on('click',function(){
    var fa_id=$(this).attr('data-value');
    var fa_name=$(this).attr('data-text');
    $('.modal-head').html('Deleting '+fa_name+'...');
    $.ajax({
        url:'mgmt/facility/fa-delete.php',
        type:'POST',
        data:{'fa_id':fa_id,'fa_name':fa_name,confirm:0},
        success:function(response){
            $('.modal-body').html(response);
        }
    });
    $('.modal').show();
    $('.overlay').show();
});