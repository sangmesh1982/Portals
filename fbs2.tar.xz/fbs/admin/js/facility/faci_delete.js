$('.faci-delete').on('click',function(){
    $('.fbs-err').removeClass('modalClose');
    $('.fbs-err').show();
    var fa_id = $(this).attr('data-value');
    var fa_name = $(this).attr('data-text');
    $.ajax({
        url:'mgmt/facility/fa-delete.php',
        type:'POST',
        data:{'fa_id':fa_id,'fa_name':fa_name,'confirm':1},
        success:function(response){
            $('.fbs-err').html(response);  
            tbl_reload();  
        }
    });
    $('.modal').hide();
    $('.overlay').hide();

    setTimeout(function(){
        $('.fbs-err').addClass('modalClose');
    },4000);
});
