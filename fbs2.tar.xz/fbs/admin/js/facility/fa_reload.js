function tbl_reload(){
    $.ajax({
        url:'mgmt/facility/faci-tbl.php',
        success:function(response){
            $('.avb-faci').html(response);
        }
    });
};
