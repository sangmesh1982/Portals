$('.faci-edit').on('click',function(){
    $('.fbs-err').removeClass('modalClose');
    $('.fbs-err').show();
    var fa_id = $('.fa_name').attr('data-val');
    var fa_name = $('.fa_name').val();
    var fa_cap = $('.fa_cap').val();
    var fa_desc = $('.fa_desc').val();
    $.ajax({
        url:'mgmt/facility/faci-update.php',
        type:'POST',
        data:{'fa_id':fa_id,'fa_name':fa_name,'fa_cap':fa_cap,'fa_desc':fa_desc},
        success:function(response){
            $('.fbs-err').html(response);  
            tbl_reload();
        }
    });
    $('.modal').hide();
    $('.overlay').hide();
    setTimeout(function(){
        $('.fbs-err').addClass('modalClose');
    },4000);
});
