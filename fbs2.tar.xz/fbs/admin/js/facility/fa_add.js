$('.faci-new').focus();
$('.faci-save').on('click',function(){
    $('.fbs-err').removeClass('modalClose');
    $('.fbs-err').show();
    var faci_new = $('.faci-new').val();
    var faci_cap = $('.faci-cap').val();
    var faci_descr = $('.faci-descr').val();
    if(faci_new==''){
        $('.faci-err').html("Facility Name should not Blank ! ");
    }
    else if(faci_new!=''){
        $('.faci-err').html("");
    } 
    if(faci_cap=='' || faci_cap=='0'){
        $('.faci-err').append(" Capacity should not Blank !");
    }
    if(faci_new!='' && faci_cap!=''){
        $.ajax({
            url:'mgmt/facility/faci-add.php',
            type:'POST',
            data:{'faci_new':faci_new,'faci_cap':faci_cap,'faci_descr':faci_descr},
            success:function(response){
                $('.fbs-err').html(response);  
                tbl_reload(); 
            }
        });
        setTimeout(function(){
            $('.fbs-err').addClass('modalClose');
        },4000);
    }
});