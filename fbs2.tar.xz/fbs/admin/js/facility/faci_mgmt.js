    $('.modal').hide();
    $('.overlay').hide();
    $('.modal').removeClass('modalClose');

    $('.faci-new-btn').on('click',function(){
        $.ajax({
            url:'mgmt/facility/fa-add.php',
            success:function(response){
                $('.modal-body').html(response);
                $('.modal-head').html('Add New Facility...');
                $('.modal').show();
                $('.overlay').show();
            }
        })
    });
    tbl_reload();
    $('.modal-close').on('click',function(){
        $('.modal').addClass('modalClose');
        $('.overlay').hide();
        setTimeout(function(){
            $('.modal').removeClass('modalClose');
            $('.modal').hide();
        },400);
        
    });
    
  
    
    


