
$(document).ready(function(){
var uid = $('.logged').attr('data-val');
if(uid!=''){
    $.ajax({
            url:'common/left-nav.php',
            type:'POST',
            data:{'uid':uid},
            success:function(response){
                $('.left-div').html(response);
            }
    });
    $.ajax({
            url:'mgmt/booking/book-mgmt.php',
            success:function(response){
                $('.right-div').html(response);
            }
    });
    $.ajax({
        url:'mgmt/booking/user_facis.php',
        type:'POST',
        data:{'uid':uid},
        success:function(response){
            $('.faci-list').html(response);
        }
    });
}
$('.logo').on('click',function(){
    $('.modal-head').html('Logo Setup...');
    $.ajax({
        url:'setup/logo.php',
        type:'POST',
        data:{'logo_url':''},
        success:function(response){
            $('.modal-body').html(response);
        }
    });
    $('.overlay').show();
    $('.modal').show();
})

$('.modal-close').on('click',function(){
    $('.modal').addClass('modalClose');
    $('.overlay').hide();
    setTimeout(function(){
        $('.modal').removeClass('modalClose');
        $('.modal').hide();
    },400);
    
});

})