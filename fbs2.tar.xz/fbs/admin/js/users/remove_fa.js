$('.avl-btn').on('click',function(){
    var fa_id=$(this).attr('data-fac-val');
    var uid=$(this).attr('data-uid-val');
    $('.avl-btn').removeClass('clicked');
    $(this).removeClass('selected-fa');
    $(this).addClass('avl-fa');
    $(this).addClass('clicked');
    $.ajax({
        url:'mgmt/users/user-assign.php',
        type:'POST',
        data:{'uid':uid,'fcid':fa_id,'assign':'resume'},
        success:function(response){
            $('.clicked').children('.fa-sense').html(response);
        }
    });
})