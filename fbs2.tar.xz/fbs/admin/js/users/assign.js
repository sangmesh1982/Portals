$('.avlbtn').on('click',function(){

    if($(this).hasClass('selected-fa')!=true && $(this).hasClass('avl-fa')!=true){    
        var fa_id=$(this).attr('data-fac-val');
        var uid=$(this).attr('data-uid-val');
        $(this).addClass('selected-fa');
        $.ajax({
            url:'mgmt/users/user-assing.php',
            type:'POST',
            data:{'uid':uid,'fcid':fa_id,'assign':'assign'},
            success:function(response){
                $(this).children('.fa-sense').html(response);
            }
        });
        return;
    }    
    if($(this).hasClass('selected-fa')==true){
        var fa_id=$(this).attr('data-fac-val');
        var uid=$(this).attr('data-uid-val');
        $(this).removeClass('selected-fa');
        $(this).addClass('avl-fa');
        $.ajax({
            url:'mgmt/users/user-assign.php',
            type:'POST',
            data:{'uid':uid,'fcid':fa_id,'assign':'resume'},
            success:function(response){
                $(this).children('.fa-sense').html(response);
            }
        });
        return;
    }
    if($(this).hasClass('avl-fa')==true){
        var fa_id=$(this).attr('data-fac-val');
        var uid=$(this).attr('data-uid-val');
        $(this).removeClass('avl-fa');
        $(this).addClass('selected-fa');
        $.ajax({
            url:'mgmt/users/user-assign.php',
            type:'POST',
            data:{'uid':uid,'fcid':fa_id,'assign':'assign'},
            success:function(response){
                $(this).children('.fa-sense').html(response);
            }
        });
        return;
    }

})