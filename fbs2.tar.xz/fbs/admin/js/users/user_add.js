$('.pass-eye').on('mouseover',function(){
    $('#user-pass1').prop("type","text");
    $('#user-pass2').prop("type","text");
})

$('.pass-eye').on('mouseleave',function(){
    $('#user-pass1').prop("type","password");
    $('#user-pass2').prop("type","password");
})

$('.user-pass2').on('blur',function(){
    var pass1=$('#user-pass1').val();
    var pass2=$(this).val();
    if(pass1!==pass2){
        $('.user-err').html('Password is not Maching!');
        $('#user-pass1').focus();
    }
    else{
        $('.user-err').html('');
    }
});

$('.user-name').focus();
$('.user-save-btn').on('click',function(){
    $('.fbs-err').removeClass('modalClose');
    $('.fbs-err').show();
    var name=$('.user-name').val();
    var uname=$('.user-new').val();
    var pass1=$('.user-pass1').val();
    var pass2=$('.user-pass2').val();
    var email=$('.user-email').val();
    var role=$('.user-role').val();
    var encypss='';
    if(name==''){
        $('.user-err').html("Name should not blank !");
        }
        else if(uname==''){
            $('.user-err').html("Username should not blank !");
        }
        else if(pass1==''){
            $('.user-err').html("Password should not blank !");
        }
        else if(pass1!==pass2){
                $('.user-err').html("Password Mismach!");
        }
        else if(email==''){
        $('.user-err').html("email should not blank !");
        }
        else if(role==null){
            $('.user-err').html("Role should be select !");
        }
    else{
        var level=$('.user-role option:selected').attr('data-val');
        $.ajax({
            url:'mgmt/users/new-user.php',
            type:'POST',
            data:{'data':pass1,'add':'no'},
            success:function(response){
                encypss=response;
                $.ajax({
                    url:'mgmt/users/new-user.php',
                    type:'POST',
                    data:{'name':name,'uname':uname,'pass':encypss,'email':email,'level':level,'add':'yes'},
                    success:function(response){
                        $('.fbs-err').html(response);
                        utbl_reload();
                    }
                });
                utbl_reload();
                $('.modal').addClass('modalClose');
                $('.overlay').hide();
                setTimeout(function(){
                    $('.modal').removeClass('modalClose');
                    $('.modal').hide();
                },400);
                
            }
        });
        setTimeout(function(){
            $('.fbs-err').addClass('modalClose');
        },4000); 
    }   
});



