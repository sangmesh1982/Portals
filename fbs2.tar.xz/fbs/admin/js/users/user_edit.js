$('.pass-eye').on('mouseover',function(){
    $('#user-pass1').prop("type","text");
       
})
$('.pass-eye').on('mouseleave',function(){
    $('#user-pass1').prop("type","password");
})

$('.user-update-btn').on('click',function(){
    $('.fbs-err').removeClass('modalClose');
    $('.fbs-err').show();
    var name=$('.user-name').val();
    var uname=$('.user-new').val();
    var pass1=$('.user-pass1').val();
    var email=$('.user-email').val();
    var role=$('.user-role').val();
    var encypss='';
    if(name==''){
        $('.user-err').html("Name should not blank !");
        }
        else if(uname==''){
            $('.user-err').html("Username should not blank !");
        }
        else if(pass1==''){
            $('.user-err').html("Password should not blank !");
        }
        else if(email==''){
        $('.user-err').html("email should not blank !");
        }
        else if(role==null){
            $('.user-err').html("Role should be select !");
        }
    else{
        var level=$('.user-role option:selected').attr('data-val');
        var uid=$('.user-new').attr('data-val');
        $.ajax({
                url:'mgmt/users/user-update.php',
                type:'POST',
                data:{'uid':uid,'name':name,'uname':uname,'pass':pass1,'email':email,'level':level,'confirm':'update'},
                success:function(response){
                    $('.fbs-err').html(response);
                    utbl_reload();
                }
        });
        
        $('.modal').addClass('modalClose');
        $('.overlay').hide();
        setTimeout(function(){
            $('.modal').removeClass('modalClose');
            $('.modal').hide();
        },400);
        
        setTimeout(function(){
            $('.fbs-err').addClass('modalClose');
        },4000);
    }  
});

