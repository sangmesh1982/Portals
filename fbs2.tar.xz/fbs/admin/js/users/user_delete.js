$('.usr-delete').on('click',function(){
    $('.fbs-err').removeClass('modalClose');
    $('.fbs-err').show();
    var user_id=$(this).attr('data-value');
    var user_name=$(this).attr('data-text');
    $('.modal-head').html('Deleting '+user_name+'...');
    $.ajax({
        url:'mgmt/users/user-delete.php',
        type:'POST',
        data:{'user_id':user_id,'user_name':user_name,confirm:1},
        success:function(response){
            $('.fbs-err').html(response);
            utbl_reload();
        }
    });
    $('.modal').hide();
    $('.overlay').hide();
    setTimeout(function(){
        $('.fbs-err').addClass('modalClose');
    },4000); 
});