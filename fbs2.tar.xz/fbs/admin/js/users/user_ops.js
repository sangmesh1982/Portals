$('.user-update').on('click',function(){
    var uid = $(this).attr('data-value');
    $('.modal-head').html('Edit '+$(this).attr('data-text')+'...');
    $.ajax({
        url:'mgmt/users/user-edit.php',
        type:'POST',
        data:{'uid':uid},
        success:function(response){
            $('.modal-body').html(response);
        }
    });
    $('.modal').show();
    $('.overlay').show();
});

$('.user-assign').on('click',function(){
    var uid = $(this).attr('data-value');
    $('.modal-head').html('Assign Facilities to '+$(this).attr('data-text')+'...');
    $.ajax({
        url:'mgmt/users/user-assign.php',
        type:'POST',
        data:{'uid':uid,'fcid':'','assign':'list'},
        success:function(response){
            $('.modal-body').html(response);
        }
    });
    $('.modal').show();
    $('.overlay').show();
});

$('.user-delete').on('click',function(){
    var user_id=$(this).attr('data-value');
    var user_name=$(this).attr('data-text');
    $('.modal-head').html('Deleting '+user_name+'...');
    $.ajax({
        url:'mgmt/users/user-delete.php',
        type:'POST',
        data:{'user_id':user_id,'user_name':user_name,confirm:0},
        success:function(response){
            $('.modal-body').html(response);
        }
    });
    $('.modal').show();
    $('.overlay').show();
});
