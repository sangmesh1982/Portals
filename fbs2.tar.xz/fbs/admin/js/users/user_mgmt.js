$('.modal').hide();
$('.overlay').hide();
$('.modal').removeClass('modalClose');

$('.user-add-btn').on('click',function(){
    $('.modal-head').html('Add New User...');
    $.ajax({
        url:'mgmt/users/user-add.php',
        success:function(response){
            $('.modal-body').html(response);
        }
    });
    $('.modal').show();
    $('.overlay').show();
});

$('.modal-close').on('click',function(){
    $('.modal').addClass('modalClose');
    $('.modal-body').html('');
    $('.overlay').hide();
    setTimeout(function(){
        $('.modal').removeClass('modalClose');
        $('.modal').hide();
    },400);
    
});






