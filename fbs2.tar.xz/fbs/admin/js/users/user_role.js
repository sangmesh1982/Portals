
$('.role-add-btn').on('click',function(){
    $('.modal-head').html('Add New Role...');
    $.ajax({
        url:'mgmt/users/user-role-add.php',
        success:function(response){
            $('.modal-body').html(response);
            $('.role-name').focus();
            $('.role-cord').prop('checked','true');
        }
    });
    $('.modal').show();
    $('.overlay').show();
});
$('.role-save-btn').on('click',function(){
    var role_nm = $('.role-name').val();
    var role_lvl = $('[name="radio-g1"]:checked').attr('data-val');
    $('.modal-head').html('Add New Role...');
    if(role_nm=='' || role_lvl==''){
        $('.role-msg').html("Name Should not Blank !");
    }
    else{        
        $.ajax({
            url:'mgmt/users/user-role-add.php',
            type:'POST',
            data:{'role':role_nm,'level':role_lvl},
            success:function(response){
                $('.modal-body').html(response);
            }
        });
        $('.modal').show();
        $('.overlay').show();
    }
});