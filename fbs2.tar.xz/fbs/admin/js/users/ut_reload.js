function utbl_reload(){
    $.ajax({
        url:'mgmt/users/user-tbl.php',
        success:function(response){
            $('.avb-user').html(response);
        }
    });
};