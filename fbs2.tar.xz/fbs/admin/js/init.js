$(document).ready(function(){
    $('.modal-head').html('Login...');
    $.ajax({
        url:'common/login.php',
        success:function(response){
            $('.modal-body').html(response);
            $('.uname').focus();
        },
    });

    $('.modal-close').on('click',function(){
        $('.modal').addClass('modalClose');
        $('.overlay').hide();
        $('.modal-head').html('');
        $('.modal-body').html('');
        setTimeout(function(){
            $('.modal').removeClass('modalClose');
            $('.modal').hide();
        },400);
        
    });
     $('.footer').html("@ Designed and Developed By Sangameshwar Gharanikar | for more projects visit <a style='color:#44ee77;' href='https://github.com/sangmesh1982/Portals' target='_blank'>Git Repository</a>");
})