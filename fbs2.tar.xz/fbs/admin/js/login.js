$('.login-btn').on('click',function(){
    $('.fbs-err').removeClass('modalClose');
    var uname=$('.uname').val();
    var upass=$('.upass').val();
    var init;
    var log_id;
    var log_un;
    if(uname =='' || upass == ''){
        $('.fbs-err').html('Invalid Credentials !');
    }
    else{
        $.ajax({
            url:'common/auth.php',
            type:'POST',
            dataType:'json',
            data:{'uname':uname,'upass':upass},
            success:function(response){
                $('.fbs-err').text(response.msg);
                init=response.msg;
                log_id=response.userid;
                log_un=response.username;
                if(init=='success'){;
                    console.log(init);
                    $('.header').append("<div class='logged' data-val='"+log_id+"'>Hello "+log_un+" !</div>");
                    $.ajax({
                        url:'common/load.php',
                        success:function(response){
                            $('.modal').hide();
                            $('.overlay').hide();
                            $('.modal-head').html('');
                            $('.modal-body').html('');
                            $('.body').html(response);
                        }
                    })
                }
            }
        })
    }
    setTimeout(function(){
        $('.fbs-err').addClass('modalClose');
    },4000);
})


$('.upass').on('keypress',function(e){
    var key = e.which;
    if(key=='13'){
        $('.fbs-err').removeClass('modalClose');
        var uname=$('.uname').val();
        var upass=$('.upass').val();
        var init;
        if(uname =='' || upass == ''){
            $('.fbs-err').html('Invalid Credentials !');
        }
        else{
            $.ajax({
                url:'common/auth.php',
                type:'POST',
                dataType:'json',
                data:{'uname':uname,'upass':upass},
                success:function(response){
                    $('.fbs-err').text(response.msg);
                    init=response.msg;
                    log_id=response.userid;
                    log_un=response.username;
                    if(init=='success'){
                        $('.header').append("<div class='logged' data-val='"+log_id+"'>Hello "+log_un+" !</div>");
                        console.log(init);
                        $.ajax({
                            url:'common/load.php',
                            success:function(response){
                                $('.modal').hide();
                                $('.overlay').hide();
                                $('.modal-head').html('');
                                $('.modal-body').html('');
                                $('.body').html(response);
                            }
                        })
                    }
                }
            })
        }
        setTimeout(function(){
            $('.fbs-err').addClass('modalClose');
        },4000);
    }
})

$('.fergot-pass').on('click',function(){
    $('.modal-body').html("<h3>Contact to IT Department !</h3>");
})

$('.l-eye').on('mouseover',function(){
    $('#login-pass').prop("type","text");
})

$('.l-eye').on('mouseleave',function(){
    $('#login-pass').prop("type","password");
})