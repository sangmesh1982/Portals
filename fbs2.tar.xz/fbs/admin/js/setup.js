$('.db_pass').focus();

$('.pass-eye').on('mouseover',function(){
    $('.db_pass').prop('type','text');
    $('.fbs_db_pass1').prop('type','text');
    $('.fbs_db_pass2').prop('type','text');
    $('.site_adm_pass1').prop('type','text');
    $('.site_adm_pass2').prop('type','text');
})

$('.pass-eye').on('mouseout',function(){
    $('.db_pass').prop('type','password');
    $('.fbs_db_pass1').prop('type','password');
    $('.fbs_db_pass2').prop('type','password');
    $('.site_adm_pass1').prop('type','password');
    $('.site_adm_pass2').prop('type','password');
})

$('.fbs-create').on('click',function(){
    
    var db_pass=$('.db_pass').val();
    var fbs_db_pass1=$('.fbs_db_pass1').val();
    var fbs_db_pass2=$('.fbs_db_pass2').val();
    var site_adm_pass1=$('.site_adm_pass1').val();
    var site_adm_pass2=$('.site_adm_pass2').val();
    $('.modal-head').html('FBS Setup...');
    if (db_pass=='' || fbs_db_pass1=='' || fbs_db_pass2=='' || site_adm_pass1=='' || site_adm_pass2 == ''){
        $('.modal-body').html('<h4>Password Can not be Blank!</h4>');
        $('.modal').show();
        $('.overlay').show();
    }
    else if (fbs_db_pass1!=fbs_db_pass2){
        $('.modal-body').html('<h4>Password for DB not Matching!</h4>');
        $('.modal').show();
        $('.overlay').show();
        $('.fbs_db_pass1').focus();
    }
    else if (site_adm_pass1!=site_adm_pass2){
        $('.modal-body').html('<h4>Password for Admin not Matching!</h4>');
        $('.modal').show();
        $('.overlay').show();
        $('.site_adm_pass1').focus();
    }
    else{
        $('.modal').show();
        $('.overlay').show();
        $('.modal-body').html('<h4>Setting Up<span class="dots"></span></h4>');
        $.ajax({
            url:'admin/setup/create.php',
            type:'POST',
            data:{'db_pass':db_pass,'fbs_pass':fbs_db_pass1,'site_adm':site_adm_pass1},
            success:function(response){
                $('.modal-body').html(response);
                if($('.setup').hasClass('done')){
                    $('.modal-body').html('<h4>Done ! Loading Admin Console<span class="dots"></span></h4>');
                    setTimeout(function(){var url = $(window.location)[0];
                    $(window.location)[0].replace(url+'/admin');
                    },3000);
                }
            }
        })
    }

});
const intr = setInterval(function(){ccc();},2000);
function ccc(){
    
    setTimeout(function(){$('.dots').html('.');},500);
    setTimeout(function(){$('.dots').html('..');},1000);
    setTimeout(function(){$('.dots').html('...');},1500);
    
}