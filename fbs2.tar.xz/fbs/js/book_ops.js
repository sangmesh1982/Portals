$('.event').focus();
$('.book-save').on('click',function(){
    $('.fbs-err').html('');
    $('.fbs-err').removeClass('modalClose');
    var fa_id=$(this).attr('data-val');
    var name=$('.name').val();
    var email=$('.email').val();
    var event=$('.event').val();
    var start_date=$('.std').val();
    var end_date=$('.etd').val();
    var descr=$('.descr').val();
    if(name==''){
        $('.msg').text("Name should not Blank !");
        }
        else if (event=='')
        {
            $('.msg').text("Event should not Blank !");
        }
            else if (start_date=='')
            {
                $('.msg').text("Start Date & Time should not Blank !");
            }
                else if (end_date=='')
                {
                        $('.msg').text("End Date & Time should not Blank !");
                }
                else{
                        $.ajax({
                        url:'php/request.php',
                        type:'POST',
                        data:{'fa_id':fa_id,'name':name,'email':email,'event':event,'start':start_date,'end':end_date,'descr':descr},
                        success:function(response){
                            $('.fbs-err').html(response);
                            tbl_reload(fa_id);
                            $('.modal').hide();
                            $('.overlay').hide();
                            setTimeout(function(){$('.fbs-err').addClass('modalClose');},5000);
                        }
                    });
                }
               
});

