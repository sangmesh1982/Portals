$('.book-btn').on('click',function(){
    var fa_id=$(this).attr('data-val');
    var fa_name=$(this).attr('data-text');
    $.ajax({
        url:'php/book.php',
        type:'POST',
        data:{'fa_id':fa_id},
        success:function(response){
            $('.modal-body').html(response);
        }
    });
    $('.overlay').show();
    $('.modal').show();
    $('.modal-head').html(fa_name + ' Booking...');
})