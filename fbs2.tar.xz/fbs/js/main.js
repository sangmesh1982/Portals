$(document).ready(function(){
        $('.l-btn').on("click",function(){
            var prop=$(this).attr('data-text');
            $('.l-btn').addClass('grey');
            $('.l-btn').removeClass('green');
            $(this).addClass('green');
            
            if(prop=='dashboard'){
                $.ajax({
                    url:'common/dashboard.php',
                    success:function(response){
                        $('.right-div').html(response);
                    },
                });
            }
            else if(prop=='booking-mgmt'){
                $.ajax({
                    url:'mgmt/booking/book-mgmt.php',
                    success:function(response){
                        $('.right-div').html(response);
                    },
                });
            }
            else if(prop=='faci-mgmt'){
                $.ajax({
                    url:'mgmt/facility/fa-mgmt.php',
                    success:function(response){
                        $('.right-div').html(response);
                    },
                });
                tbl_reload();
            }
            else if(prop=='user-mgmt'){
                $.ajax({
                    url:'mgmt/users/user-mgmt.php',
                    success:function(response){
                        $('.right-div').html(response);
                    },
                });
                utbl_reload();
            }
            else if(prop=='logout'){
                location.reload();
            }
        });
})