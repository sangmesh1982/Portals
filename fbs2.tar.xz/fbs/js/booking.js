$('.avlbtn').on('click',function(){
    var fa_id = $(this).attr('data-fac-val');
    $.ajax({
        url:'php/booked.php',
        type:'POST',
        data:{'fa_id':fa_id},
        success:function(response){
            $('.book-tbl').html(response);
        }
    })
    $('.avlbtn').removeClass('selected-fa');
    $(this).addClass('selected-fa');
})