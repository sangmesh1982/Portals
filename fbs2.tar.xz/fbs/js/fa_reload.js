function tbl_reload(fa_id){
    $.ajax({
        url:'php/booked.php',
        type:'POST',
        data:{'fa_id':fa_id},
        success:function(response){
            $('.book-tbl').html(response);
        }
    });
}