$(document).ready(function(){
$('.modal').hide();
$('.overlay').hide();    
$.ajax({
        url:'php/check.php',
        success:function(response){
            var res=response;
            
            if(res=='true'){
                $.ajax({
                    url:'php/facility.php',
                    success:function(response1){
                    $('.avb-faci').html(response1);
                    }
                })
            }
            else if(res=='false'){
                $('.header').html('');
                $('.left-div').html('');
                $('.right-div').html('');
                $.ajax({
                    url:'admin/setup/setup.php',
                    success:function(response1){
                    $('.right-div').html(response1);
                    }
                })
            }
        }
 });

$('.modal-close').on('click',function(){
    $('.modal').addClass('modalClose');
    $('.overlay').hide();
    setTimeout(function(){
        $('.modal').removeClass('modalClose');
        $('.modal').hide();
    },400);
});

$('.login').on('click',function(){
    var url = $(window.location)[0];
    $(window.location)[0].replace(url+'/admin');
})

$('.footer').html("@ Designed and Developed By Sangameshwar Gharanikar | for more projects visit <a style='color:#44ee77;' href='https://github.com/sangmesh1982/Portals' target='_blank'>Git Repository</a>");    
})