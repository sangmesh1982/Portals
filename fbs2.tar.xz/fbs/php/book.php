<script src="js/book_ops.js"></script>
<script src="js/fa_reload.js"></script>
<div class='book-form'>
    <div class='col-1'>
        <div class='form-l'>Event* :</div>
        <div class='form-l'>Booking By* :</div>
        <div class='form-l'>eMail :</div>
        <div class='form-l'>Start Date* :</div>
        <div class='form-l'>End Date* :</div>
        <div class='form-l'>Description :</div>
    </div>
    <div class='col-2'>
        <div class='form-i'><input type='text' id='event' class='event book-ele' /></div>
        <div class='form-i'><input type='text' id='name' class='name book-ele' /></div>
        <div class='form-i'><input type='email' id='email' class='email book-ele' /></div>
        <div class='form-i'><input type='datetime-local' id='std' class='std book-ele' /></div>
        <div class='form-i'><input type='datetime-local' id='etd' class='etd book-ele' /></div>
        <div class='form-i'><textarea  id='descr' class='descr book-ele' cols='22' rows='2'></textarea></div>
    </div>
</div>
<center><div class='msg'></div></center>
<?php
$fa_id=$_POST['fa_id'];
echo "<center><div class='fbs-btn book-save' data-val='$fa_id'>Save</div></center>";
?>