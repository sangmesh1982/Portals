<?php
require_once('../admin/config/config.php');
$faid=$_POST['fa_id'];
$name=$_POST['name'];
$email=$_POST['email'];
$event=$_POST['event'];
$start_dt=$_POST['start'];
$end_dt=$_POST['end'];
$desc=$_POST['descr'];
if($start_dt < date('Y-m-d')){
    echo "Back-dated Events can not Register !";
    exit();
}
$a=array($faid,$name,$email,$event,$start_dt,$end_dt,$desc);
$b=array('faci_id','request_by','email','event','start_time','end_time','description');
$qc=select_query($suf.'bookings',$s=array($faid,$start_dt),$t=array('faci_id','start_time'));
$row=$qc->fetch_row();
if($row[0]==null){
    $q=insert_query($suf.'bookings',$a,$b);
    if($q=='true'){
        $form=$email;
        $qf=select_query($suf.'facilities',$a=array($faid),$b=array('id'));
        $frow=$qf->fetch_row();
        $sub='Booking Request for '.$frow[1];
        $m_body="
            <div class='fbs-btn'>Bokking Request for ".$frow[1]."</div>
            <div> Request by :".$name." </div>
            <div> Event :".$event." </div>
            <div> Start Time :".$start_dt." To : ".$end_dt."</div>
            <div> Description :".$desc."</div>
        ";

        // Always set content-type when sending HTML email
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

        // More headers
        $headers .= 'From: '.$email. "\r\n";
        //$headers .= 'Cc: myboss@example.com' . "\r\n";

        $qf=select_query($suf.'faci_assign',$af=array($faid),$bf=array('facid'));
        $uto=array();
        while($fass=$qf->fetch_array()){
            $uto[]=$fass['userid'];
        }
        foreach($uto as $toid){
            $qt=select_query($suf.'users',$au=array($toid),$bu=array('id'));
            $uem=$qt->fetch_row();
            mail($uem[4],$sub,$m_body,$headers);
           
        }
        echo "Request has been booked ! Pending for confirmation !";
    }
    else{
        echo "Server Error !";
    }
}    
else{
    echo "Conflicting with other Event !";
}
?>