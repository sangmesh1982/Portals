<?php
mysqli_report(MYSQLI_REPORT_OFF);
require('../admin/config/db_str.php');
$con = $conn;

if ($con->connect_errno) {
    echo "false";
    exit();
}
if (!$con->connect_errno) {
    echo "true";
    exit();
}


?> 