<script src="js/book.js"></script>
<?php
require_once('../admin/config/config.php');
$faid=$_POST['fa_id'];
$qf=select_query($suf.'facilities',$d=array($faid),$f=array('id'));
$faname=$qf->fetch_row();
echo '<div class="fbs-btn book-btn" data-val='.$faid.' data-text="'.$faname[1].'">Book</div>
      <h3>'.$faname[1].'</h3>';
$date=date('Y-m-d H:i:s');
?>

<table>
    <tr class='thead'>
        <th>Sr No</th><th>Request by</th><th>Event</th><th>Description</th><th>Start Time</th><th>End Time</th><th>Request Date</th><th>Status</th><th>Remark</th>
    </tr>
             <?php 
                
                $q=select_query($suf.'bookings',$a=array($faid,'0'),$b=array('faci_id','removed'));
                $i=1;
                    while($rw=$q->fetch_array()){
                        if($rw['end_time']>=$date){
                            echo "<tr>
                                    <td align='center'>".$i."</td>
                                    <td>
                                        ".$rw['request_by']."
                                    </td>
                                    <td align='center'>
                                        ".$rw['event']."
                                    </td>
                                    <td align='center'>
                                        ".$rw['description']."
                                    </td>
                                    <td>
                                        ".$rw['start_time']."
                                    </td>
                                    <td>
                                        ".$rw['end_time']."
                                    </td>
                                    <td>
                                        ".$rw['request_on']."
                                    </td>
                                    <td>
                                    ";
                                    if($rw['approval']=='-1'){
                                            echo '<div class="red">Rejected</div>';
                                        }
                                        else if($rw['approval']=='1'){
                                            echo '<div class="green">Approved</div>';
                                        }
                                        else{
                                            echo 'Pending...';
                                        }
                                    echo "</td>
                                    <td>
                                        ".$rw['remark']."
                                    </td>
                                </tr>";
                            $i++;
                        }
                    }
                     
            ?> 
</table> 
