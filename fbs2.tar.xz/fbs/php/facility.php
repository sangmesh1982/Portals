<script src="js/booking.js"></script>
<script src="js/fa_reload.js"></script>
<?php
    require_once('../admin/config/config.php');
    $q=select_query($suf.'facilities',$a=array(),$b=array());
    echo "<div class='fava'>";
    $i=1;
    while($qrow=$q->fetch_array()){
        $qr=select_query($suf.'faci_assign',$a=array($uid,$qrow['id']),$b=array('userid','facid'));
        $row=$qr->fetch_row();
        if($row[0]==null){
            if($i=='1'){
                echo '<div class="avlbtn avl-fa blue selected-fa" data-fac-val="'.$qrow['id'].'" >'.$qrow['facility'].'</div>';
                ?><script>tbl_reload(<?php echo $qrow['id']; ?>);</script><?php
            }
            else{
                echo '<div class="avlbtn avl-fa blue" data-fac-val="'.$qrow['id'].'" >'.$qrow['facility'].'</div>';
            }    
        }    
        $i++;
    }
    echo "</div>";
?>