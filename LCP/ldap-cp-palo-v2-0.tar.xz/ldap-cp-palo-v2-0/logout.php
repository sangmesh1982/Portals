<?php
/*
`````````````````````````````````````````````````````````````````````````````````
Customised Capative Portal for PaloAlto Firewall to Authenticate LDAP Users

Date : 20/April/2026
Author : Sangameshwar Gharanikar

This PHP is for unmapping the LDAP user from current IP adresss 
and clear session

Initial Release 2.0
`````````````````````````````````````````````````````````````````````````````````
*/

require_once('environ.php');

$json = file_get_contents("php://input");
$data = json_decode($json,true);

$serial = $env['SR'];
$sys = ['SM'];

$user = $env['LDAP_SL'].$data['user'];
$ip = $data['ip'];

$url = $env['API_URL'].'?type=user-id&key='.$env['API_KEY'];
$cont = $env['CMD_Lo_O'].'<entry name="'.$user.'" ip="'.$ip.'" timeout="0"></entry>'.$env['CMD_Lo_C'];

$prefix = $user.'-tmp.xml';
$tmp_path = 'tmp/';

if($tmp_path){
	$tmp_wr = fopen($tmp_path.$prefix,'w+');
	if($tmp_wr){
		fwrite($tmp_wr,$cont);
		fclose($tmp_wr);
		$l_dtls = file_get_contents($tmp_path.$prefix);
		$curl = curl_init();
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER,0);
		curl_setopt($curl, CURLOPT_SSL_VERIFYHOST,0);
		curl_setopt($curl, CURLOPT_POST, true);
		curl_setopt($curl, CURLOPT_POSTFIELDS,'cmd='.urlencode($l_dtls));
		curl_setopt($curl, CURLOPT_RETURNTRANSFER,1);
		curl_setopt($curl, CURLOPT_URL,$url);
		$resp = curl_exec($curl);
		$rerr = curl_error($curl);
		if(strpos($resp,'status="success"')!==false){
			$msg = ['message'=>'Logged Out Successfully !','state'=>'OK'];
		}
		else{
			$msg = ['message'=>'Error While LogOut !','state'=>'NOT'];
		}
		unlink($tmp_path.$prefix);
		curl_close($curl);
	}
}
else{
	$msg = ['message'=>'Check if tmp folder is there!','state'=>'NOT'];
}
echo json_encode($msg);
curl_close($curl);

?>
