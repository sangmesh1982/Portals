<?php include "conn.php";
	
$nm=$_POST['name'];
$ev=$_POST['event'];
$fc=$_POST['faci'];
$rd=$_POST['rdt'];
$lrd=$_POST['rldt'];
$st=$_POST['stime'];
$et=$_POST['etime'];
$ct=time();
$ctt=date("Y-m-d H:i:s",$ct);
$ctf=date("d-m-Y",strtotime($rd));

if ($nm=='' or $ev=='' or $rd=='' or $st=='' or $et=='')
{

$er="<font color='red'>Fields should not Blank !</font>";


header('Location: /?er='.$er);

exit;

}

header('Location: /');

$rdt=date("Y-m-d",strtotime($rd));

$rldt=date("Y-m-d",strtotime($lrd));

$q="insert into booking (name, event, faci, rdate, rldate, stime, etime, bkdate) values ('$nm', '$ev', '$fc', '$rdt', '$rldt', '$st', '$et', '$ctt')";

$con->query($q);


if(!mysqli_error($con))
{
$er="<font color='green'><h3>Request Registered ! Pending for Approval !</h3></font>";
ini_set('SMTP','smtp.gmail.com');
ini_set('smtp_port',465);
$header="Content-type:text/html;charset:UTF-8";
$msg="<html><head><title>Auditorium Booking Request</title></head><body><table><tr><td>FROM :</td><td> $nm </td></tr><tr><td> FOR :</td><td> $ev </td></tr><tr><td> DATED :</td><td> $ctf</td></tr><td> FROM :</td><td> $st TO $et </td></tr><tr><td colspan='2'> You can check the status on http://10.12.17.115:8890</td></tr></body></html>";
//$ml=mail("complab@sims.edu","Auditorium Booking Request",$msg,$header); 
}
else
{
$er=mysqli_error($con);
}
header('location:/?er='.$er);



?>
