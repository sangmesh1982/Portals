<!Doctype html>
<html>
    <head>
        <title>Facility Booking System</title>
        <link rel='stylesheet' href='style/style.css' />
        <script src="script/jquery-3.7.1.js"></script>
        
        <script>
            $(document).ready(function(){

                $.ajax({url:'data-table.php',
                        type:'POST',
                        data:'faci=Auditorium',
                        success:function (response){
                            $('.fa').html(response);
                        }
                    });

                $('.fa-btn').on('click',function(){
                    var faci = $(this).attr('data-text');
                    $('.fa-btn').removeClass('green');
                    $('.fa-btn').addClass('grey');
                    $(this).removeClass('grey');
                    $(this).addClass('green');
                    $.ajax({url:'data-table.php',
                        type:'POST',
                        data:'faci='+faci,
                        success:function (response){
                            $('.fa').html(response);
                        }
                    });

                });

            })
            

        </script>
    </head>
<body>
    <div class='header'>
        <center><h1>SIMS Facility Booking System</h1></center>
    </div>
    <div class='body'>
        <form action="book.php" method="post">
            <table align='center' >
            
            <tr>
            <td>Name :</td><td><input type='text' id='name' name='name' /></td>
            </tr>
            <tr>
            <td>Event :</td><td><textarea rows='4' cols='40' id='event' name='event' /></textarea></td>
            </tr>
            <tr>
            <td>Facility :</td>
                <td>
                    <select id='faci' name='faci'>
                        <option>Auditorium</option>
                        <option>Conference</option>
                        <option>Chanakya1</option>
                        <option>Chanakya2</option>
                        <option>Complab-1</option>
                        <option>Complab-2</option>
                        <option>Complab-3</option>
                        <option>VIP_Lauge</option>
                        <option>Under_Dome</option>
                        <option>Camera-Nikon(D5300)</option>
                        <option>Handycam-Panasonic(HC-V785)</option>
                        <option>Tripod</option>
                    </select>
                </td>
            </tr>
            <tr>
            <td>Require On :</td><td><input type='date' id='rdt' name='rdt' placeholder='Click to Calendar' /></td>
            </tr>
            <tr>
            <td>Require till :</td><td><input type='date' id='rldt' name='rldt' placeholder='Click to Calendar' /></td>
            </tr>
            <tr>
            <td>Event Starts at :</td><td><input type='time' id='stime' name='stime' placeholder='Click to Timer' /></td>
            </tr>
            <tr>
            <td>Event Ends at :</td><td><input type='time' id='etime' name='etime' placeholder='Click to Timer' /></td>
            </tr>
            <tr>
            <td colspan='2'>
            <center><input type='submit' id='sbmt' value='Submit' /></center>
            </td>
            </tr>
            <tr>
            <td colspan='2' align='center'><?php echo $_GET['er']; ?></td>
            </tr>
            </table>				
        </form>
         
        <table align='center'  >
            <tr>
                <td id='facil1' class='fa-btn green' data-text='Auditorium'  >AUDITORIUM</td>
                <td id='facil2' class='fa-btn grey' data-text='Conference' >CONFERENCE</td>
                <td id='facil3' class='fa-btn grey' data-text='Chanakya1' >CHANAKYA 1</td>
                <td id='facil4' class='fa-btn grey' data-text='Chanakya2' >CHANAKYA 2</td>
                <td id='facil5' class='fa-btn grey' data-text='Complab-1' >Complab 1</td>
                <td id='facil6' class='fa-btn grey' data-text='Complab-2' >Complab 2</td>
                <td id='facil12' class='fa-btn grey' data-text='Complab-3' >Complab 3</td>
                <td id='facil7' class='fa-btn grey' data-text='VIP_Lauge' >VIP-Launge</td>
                <td id='facil8' class='fa-btn grey' data-text='Under_Dome' >Under-Dome</td>
                <td id='facil9' class='fa-btn grey' data-text='Camera-Nikon(D5300)' >Camera</td>
                <td id='facil10' class='fa-btn grey' data-text='Handycam-Panasonic(HC-V785)' >Handycam</td>
                <td id='facil11' class='fa-btn grey' data-text='Tripod' >Tripod</td>
            </tr>
        </table>
        <br/>    
        <div class='fa display'></div>
        
    </div>
    <div class='footer'>

    </div>
</body>
