<table align='center' style="background:#eee;">
            <tr style="background:#888; color:#760000;"><td align='center' ><b>Book By</b></td><td align='center'><b>Event</b></td><td align='center'><b>Start Date</b></td><td align='center'><b>End Date</b></td><td align='center'><b>Event Starts</b></td><td align='center'><b>Event Ends</b></td><td align='center'><b>Status</b></td><td align='center'><b>Request on</b></td><td align='center'><b>Remark</b></td></tr>

            <?php include "conn.php";
            $faci=$_POST['faci'];
            $dt=date('Ymd');
            $tbl="select * from booking where faci='$faci' AND rldate >= '$dt' order by rdate ASC ";
            
            $rd=$con->query($tbl);
            while($rw=$rd->fetch_array())
            {
                if($rw['approval']=='')
                {
                    $st="<div style='width:100%; height:100%; background:#a7ba44'>Pending</div>";
                }
                else if($rw['approval']=='Yes')
                {
                    $st="<div style='width:100%; height:100%; background:#11dd11'>Confirm</div>";
                }
                else if($rw['approval']=='No')
                {
                    $st="<div style='width:100%; height:100%; background:#dd1111'>Cancel</div>";
                }
                echo "<tr><td>".$rw['name']."</td><td>".$rw['event']."</td><td>".date("d-m-Y",strtotime($rw['rdate']))."</td><td>".date("d-m-Y",strtotime($rw['rldate']))."</td><td>".$rw['stime']."</td><td>".$rw['etime']."</td><td>".$st."</td><td>".date('d-m-Y H:i:s',strtotime($rw['bkdate']))."</td><td>".$rw['remark']."</td></tr>";

            }

            ?>
</table>
<link rel='stylesheet' href='style/style.css' />