<?php include "conn.php";
$u=$_POST['uname'];
$p=$_POST['pass'];
$fc=$_POST['faci'];

$ur="select * from user where user='$u'";
$ru=$con->query($ur);
$rd=$ru->fetch_row();

if($rd[3]=='1')
{
echo "<div style='display:block;left:0;right:0;margin-left:auto;margin-right:auto;text-align:center;'><h2 style='' ><b>Facility </b><h3> <form method='post' action='auth.php'><input type='text' id='uname' name='uname' value='".$u."' style='display:none;'/><input type='text' id='pass' name='pass' value='".$p."' style='display:none;'/><select id='faci' name='faci'><option>Select Facility</option><option>Auditorium</option><option>Conference</option><option>Chanakya1</option><option>Chanakya2</option><option>VIP_Lauge</option><option>Under_Dome</option></select><input type='submit' value='Submit'/></div>";
}

if($rd[3]=='2')
{
echo "<div style='display:block;left:0;right:0;margin-left:auto;margin-right:auto;text-align:center;'><h2 style='' ><b>Facility </b><h3><br/> <form method='post' action='auth.php'><input type='text' id='uname' name='uname' value='".$u."' style='display:none;'/><input type='text' id='pass' name='pass' value='".$p."' style='display:none;'/><select id='faci' name='faci'><option>Select Facility</option><option>Camera-Nikon(D5300)</option><option>Handycam-Panasonic(HC-V785)</option><option>Tripod</option></select><input type='submit' value='Submit'/></div>";
}

if($rd[3]=='3')
{
echo "<div style='display:block;left:0;right:0;margin-left:auto;margin-right:auto;text-align:center;'><h2 style='' ><b>Facility </b><h3> <form method='post' action='auth.php'><input type='text' id='uname' name='uname' value='".$u."' style='display:none;'/><input type='text' id='pass' name='pass' value='".$p."' style='display:none;'/><select id='faci' name='faci'><option>Select Facility</option><option>Complab-1</option><option>Complab-2</option><option>Complab-3</option></select><input type='submit' value='Submit'/></div>";
}

$rq="select * from booking where faci='$fc' order by rdate DESC";


$rn=$con->query($rq);

echo "<table align='center' border='1'><tr><td colspan='11' align='center'><h1>SIMS Facility Booking System (Admin)</td></tr>";
echo "<tr><td align='center'><b>Booking No<b></td><td align='center'><b>Booking By<b></td><td align='center'><b>Event<b></td><td align='center'><b>Facility<b></td><td align='center'><b>Event Date<b></td><td align='center'><b>Event till Date<b></td><td align='center'><b>Event Starts at<b></td><td align='center'><b>Event Ends at<b></td><td align='center'><b>Approval<b></td><td align='center'><b>Request On</b></td><td align='center'><b>Remark<b></td>";
$n=1;


if($rd[1]==$u && $rd[2]==$p)

while($rm=$rn->fetch_array())
{

if($rm['approval']=='')
{
$st="<div style='width:100%; height:100%; background:yellow'>Pending</div>";
}
else if($rm['approval']=='Yes')
{
$st="<div style='width:100%; height:100%; background:green'>Confirm</div>";
}
else if($rm['approval']=='No')
{
$st="<div style='width:100%; height:100%; background:red'>Cancel</div>";
}
echo "<tr><td>".$n."</td><td>".$rm['name']."</td><td>".$rm['event']."</td><td>".$rm['faci']."</td><td>".date('d-m-Y',strtotime($rm['rdate']))."</td><td>".date('d-m-Y',strtotime($rm['rldate']))."</td><td>".$rm['stime']."</td><td>".$rm['etime']."</td><td>".$st."<select id='apvl".$rm['no']."' name='apvl".$rm['no']."'><option>No</option><option>Yes</option></select></td><td>".date('d-m-Y H:i:s',strtotime($rm['bkdate']))."</td><td><textarea rows='2' cols='20' id='rem".$rm['no']."' name='rem".$rm['no']."' >".$rm['remark']."</textarea></td><td><input type='button' value='Update' onclick='book(".$rm['no'].")' /></td> </tr>";
$n=$n+1;
}

else
echo "Wrong User ID or Password !";

echo "</table>";
?>

<script>
function book($j)
{
$ap=document.getElementById('apvl'+$j).value;
$re=document.getElementById('rem'+$j).value;

window.open("book.php?no="+$j+"&apv="+$ap+"&rem="+$re,"","width=100, height=100");

}
</script>
<style>
table {
    border-collapse: collapse;
}

table, th, td {
    border: 1px solid black;
}
</style>
