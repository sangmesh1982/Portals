<?php include "conn.php";

$n=$_GET['no'];
$a=$_GET['apv'];
$r=$_GET['rem'];

$q="update booking set approval='$a', remark='$r' where no='$n'";

$con->query($q);

echo "<img src='1.jpg' onload='clos()' />";
?>
<script>
function clos()
{
window.close("book.php");
}
</script>
