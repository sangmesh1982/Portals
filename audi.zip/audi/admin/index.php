<html><Head><title>SIMS Facility Booking System</title></head>
<body>
<form action="auth.php" method="post">
<table align='center'>
<tr>
<td colspan='2'><center><h1>SIMS Facility Booking System</center></td>
</tr>
<tr>
<td>User Name :</td><td><input type='text' id='uname' name='uname' /></td>
</tr>
<tr>
<td>Password :</td><td><input type='password' id='pass' name='pass' /></td>
</tr>
<tr>
<td colspan='2' align='center'><input type='submit' value='Submit' /></td>
</tr>
</table>
</form>
</body>
</html>